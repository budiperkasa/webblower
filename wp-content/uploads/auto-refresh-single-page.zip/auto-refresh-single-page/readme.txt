=== Auto Refresh Single Page ===
Contributors: jkohlbach
Donate link: http://www.codemyownroad.com
Tags: auto refresh, refresh meta, meta tags, automatic refreshing, refresh a page, refresh pages, auto refresh post, auto refresh page
Requires at least: 3.0
Tested up to: 3.2
Stable tag: trunk

Adds a little box for you to specify if a page should auto refresh after a given number of seconds.

== Description ==

Adds a little box for you to specify if a page should auto refresh after a given number of seconds.

== Installation ==

1. Upload the plugin to the '/wp-content/plugins/' directory
1. Activate the plugin through the 'Plugins' menu in WordPress

To use this plugin, when authoring a post or page, simply enter the number of seconds you wish the page to refresh after in the box on the right hand side of the edit screen.ace them.

== Frequently Asked Questions ==

= Is there a development version of this plugin? =

Yes, you can find it on github at http://github.com/jkohlbach, but it's more often than not the same version as here unless I'm actively working on it.

== Screenshots ==

N/A

== Upgrade Notice ==

N/A

== Changelog ==

* 1.0 Initial version
 - Specify seconds to auto refresh the page/post