tinyMCE.addI18n('nl.paste_dlg',{
text_title:"Gebruik Ctrl+V om tekst in het venster te plakken.",
text_linebreaks:"Regelafbreking bewaren",
word_title:"Gebruik Ctrl+V om tekst in het venster te plakken."
});