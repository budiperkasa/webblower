tinyMCE.addI18n({vi:{
common:{
edit_confirm:"B\u1EA1n c\u00F3 mu\u1ED1n s\u1EED d\u1EE5ng ch\u1EBF \u0111\u1ED9 nh\u1EADp li\u1EC7u WYSIWYG cho \u00F4 d\u1EEF li\u1EC7u n\u00E0y kh\u00F4ng?",
apply:"\u00C1p d\u1EE5ng",
insert:"Ch\u00E8n",
update:"C\u1EADp nh\u1EADt",
cancel:"H\u1EE7y",
close:"\u0110\u00F3ng",
browse:"M\u1EDF",
class_name:"L\u1EDBp",
not_set:"-- mac dinh ch\u1ECDn --",
clipboard_msg:"Sao ch\u00E9p/C\u1EAFt/D\u00E1n kh\u00F4ng ho\u1EA1t \u0111\u1ED9ng tr\u00EAn Mozilla v\u00E0 Firefox.\nB\u1EA1n mu\u1ED1n xem th\u00EAm th\u00F4ng tin v\u1EC1 v\u1EA5n \u0111\u1EC1 n\u00E0y?",
clipboard_no_support:"Hi\u1EC7n kh\u00F4ng h\u1ED5 tr\u1EE3 cho tr\u00ECnh duy\u1EC7t c\u1EE7a b\u1EA1n, vui l\u00F2ng s\u1EED d\u1EE5ng b\u00E0n ph\u00EDm.",
popup_blocked:"Xin l\u1ED7i, nh\u01B0ng tr\u00ECnh duy\u1EC7t c\u1EE7a b\u1EA1n kh\u00F4ng cho ph\u00E9p m\u1EDF c\u1EEDa s\u1ED5 m\u1EDBi (popup). B\u1EA1n c\u1EA7n ph\u1EA3i \u0111i\u1EC1u ch\u1EC9nh tr\u00ECnh duy\u1EC7t cho ph\u00E9p m\u1EDF c\u1EEDa s\u1ED5 m\u1EDBi \u0111\u1EC3 t\u1EADn h\u01B0\u1EDFng \u0111\u1EA7y \u0111\u1EE7 ch\u1EE9c n\u0103ng c\u1EE7a c\u00F4ng c\u1EE5 n\u00E0y.",
invalid_data:"L\u1ED7i: D\u1EEF li\u1EC7u kh\u00F4ng h\u1EE3p l\u1EC7, ch\u00FAng \u0111\u00E3 \u0111\u01B0\u1EE3c \u0111\u00E1nh d\u1EA5u m\u00E0u \u0111\u1ECF.",
more_colors:"Nhi\u1EC1u m\u00E0u h\u01A1n"
},
contextmenu:{
align:"C\u0103n l\u1EC1",
left:"Tr\u00E1i",
center:"Gi\u1EEFa",
right:"Ph\u1EA3i",
full:"\u0110\u1EC1u"
},
insertdatetime:{
date_fmt:"%d/%m/%Y",
time_fmt:"%H:%M:%S",
insertdate_desc:"Ch\u00E8n ng\u00E0y",
inserttime_desc:"Ch\u00E8n gi\u1EDD",
months_long:"Th\u00E1ng M\u1ED9t,Th\u00E1ng Hai,Th\u00E1ng Ba,Th\u00E1ng T\u01B0,Th\u00E1ng N\u0103m,Th\u00E1ng S\u00E1u,Th\u00E1ng B\u1EA3y,Th\u00E1ng T\u00E1m,Th\u00E1ng Ch\u00EDn,Th\u00E1ng M\u01B0\u1EDDi,Th\u00E1ng M\u01B0\u1EDDi M\u1ED9t,Th\u00E1ng M\u01B0\u1EDDi Hai",
months_short:"M\u1ED9t,Hai,Ba,T\u01B0,N\u0103m,S\u00E1u,B\u1EA3y,T\u00E1m,Ch\u00EDn,M\u01B0\u1EDDi,M.M\u1ED9t,M.Hai",
day_long:"Ch\u1EE7 Nh\u1EADt,Th\u1EE9 Hai,Th\u1EE9 Ba,Th\u1EE9 T\u01B0,Th\u1EE9 N\u0103m,Th\u1EE9 S\u00E1u,Th\u1EE9 B\u1EA3y,Ch\u1EE7 Nh\u1EADt",
day_short:"CN,Hai,Ba,T\u01B0,N\u0103m,S\u00E1u,B\u1EA3y,CN"
},
print:{
print_desc:"In"
},
preview:{
preview_desc:"Xem tr\u01B0\u1EDBc"
},
directionality:{
ltr_desc:"Direction left to right",
rtl_desc:"Direction right to left"
},
layer:{
insertlayer_desc:"Ch\u00E8n l\u1EDBp m\u1EDBi",
forward_desc:"Chuy\u1EC3n \u0111\u1EBFn tr\u01B0\u1EDBc",
backward_desc:"Chuy\u1EC3n ra sau",
absolute_desc:"Toggle absolute positioning",
content:"L\u1EDBp m\u1EDBi..."
},
save:{
save_desc:"Save",
cancel_desc:"Hu\u1EF7 t\u1EA5t c\u1EA3 thay \u0111\u1ED5i"
},
nonbreaking:{
nonbreaking_desc:"Insert non-breaking space character"
},
iespell:{
iespell_desc:"Ki\u1EC3m tra ch\u00EDnh t\u1EA3",
download:"ieSpell not detected. Do you want to install it now?"
},
advhr:{
advhr_desc:"Horizontale rule"
},
emotions:{
emotions_desc:"Bi\u1EC3u t\u01B0\u1EE3ng c\u1EA3m x\u00FAc"
},
searchreplace:{
search_desc:"T\u00ECm ki\u1EBFm",
replace_desc:"T\u00ECm/Thay th\u1EBF"
},
advimage:{
image_desc:"Ch\u00E8n/thay \u0111\u1ED5i h\u00ECnh \u1EA3nh"
},
advlink:{
link_desc:"Ch\u00E8n/thay \u0111\u1ED5i li\u00EAn k\u1EBFt"
},
xhtmlxtras:{
cite_desc:"Citation",
abbr_desc:"Abbreviation",
acronym_desc:"Acronym",
del_desc:"Deletion",
ins_desc:"Insertion",
attribs_desc:"Insert/Edit Attributes"
},
style:{
desc:"Edit CSS Style"
},
paste:{
paste_text_desc:"D\u00E1n n\u1ED9i dung v\u00E0 b\u1ECF \u0111i \u0111\u1ECBnh d\u1EA1ng",
paste_word_desc:"D\u00E1n n\u1ED9i dung sao ch\u00E9p t\u1EEB Word",
selectall_desc:"Ch\u1ECDn t\u1EA5t c\u1EA3"
},
paste_dlg:{
text_title:"S\u1EED d\u1EE5ng t\u1ED5 h\u1EE3p ph\u00EDm CTRL+V \u0111\u1EC3 d\u00E1n n\u1ED9i dung v\u00E0o khung b\u00EAn d\u01B0\u1EDBi.",
text_linebreaks:"Gi\u1EEF nguy\u00EAn nh\u1EEFng ch\u1ED7 xu\u1ED1ng h\u00E0ng",
word_title:"S\u1EED d\u1EE5ng t\u1ED5 h\u1EE3p ph\u00EDm CTRL+V \u0111\u1EC3 d\u00E1n n\u1ED9i dung v\u00E0o khung b\u00EAn d\u01B0\u1EDBi."
},
table:{
desc:"Ch\u00E8n b\u1EA3ng m\u1EDBi",
row_before_desc:"Ch\u00E8n d\u00F2ng v\u00E0o tr\u01B0\u1EDBc v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
row_after_desc:"Ch\u00E8n d\u00F2ng v\u00E0o sau v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
delete_row_desc:"X\u00F3a d\u00F2ng",
col_before_desc:"Ch\u00E8n c\u1ED9t v\u00E0o sau v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
col_after_desc:"Ch\u00E8n c\u1ED9t v\u00E0o sau v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
delete_col_desc:"X\u00F3a c\u1ED9t",
split_cells_desc:"T\u00E1ch \u00F4",
merge_cells_desc:"G\u1ED9p \u00F4",
row_desc:"Thay \u0111\u1ED5i thu\u1ED9c t\u00EDnh d\u00F2ng",
cell_desc:"Thay \u0111\u1ED5i thu\u1ED9c t\u00EDnh \u00F4",
props_desc:"Thay \u0111\u1ED5i thu\u1ED9c t\u00EDnh b\u1EA3ng",
paste_row_before_desc:"D\u00E1n d\u00F2ng v\u00E0o tr\u01B0\u1EDBc v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
paste_row_after_desc:"D\u00E1n d\u00F2ng v\u00E0o sau v\u1ECB tr\u00ED hi\u1EC7n t\u1EA1i",
cut_row_desc:"C\u1EAFt d\u00F2ng",
copy_row_desc:"Sao ch\u00E9p d\u00F2ng",
del:"X\u00F3a b\u1EA3ng",
row:"D\u00F2ng",
col:"C\u1ED9t",
cell:"\u00D4"
},
autosave:{
unload_msg:"The changes you made will be lost if you navigate away from this page."
},
fullscreen:{
desc:"B\u1EADt/t\u1EAFt ch\u1EBF \u0111\u1ED9 to\u00E0n m\u00E0n h\u00ECnh"
},
media:{
desc:"Ch\u00E8n/thay \u0111\u1ED5i media(flash, nh\u1EA1c, video ...)",
edit:"Thay \u0111\u1ED5i media"
},
fullpage:{
desc:"Document properties"
},
template:{
desc:"Insert predefined template content"
},
visualchars:{
desc:"Visual control characters on/off."
},
spellchecker:{
desc:"Ki\u1EC3m tra ch\u00EDnh t\u1EA3",
menu:"T\u00F9y ch\u1ECDn ki\u1EC3m tra ch\u00EDnh t\u1EA3",
ignore_word:"B\u1ECF qua m\u1ED9t t\u1EEB n\u00E0y",
ignore_words:"B\u1ECF qua t\u1EA5t c\u1EA3 t\u1EEB n\u00E0y",
langs:"Ng\u00F4n ng\u1EEF",
wait:"Vui l\u00F2ng \u0111\u1EE3i trong gi\u00E2y l\u00E1t...",
sug:"C\u00E1c t\u1EEB t\u01B0\u01A1ng t\u1EF1",
no_sug:"Kh\u00F4ng c\u00F3 t\u1EEB t\u01B0\u01A1ng t\u1EF1",
no_mpell:"Kh\u00F4ng c\u00F3 l\u1ED7i ch\u00EDnh t\u1EA3"
},
pagebreak:{
desc:"Insert page break."
}}});